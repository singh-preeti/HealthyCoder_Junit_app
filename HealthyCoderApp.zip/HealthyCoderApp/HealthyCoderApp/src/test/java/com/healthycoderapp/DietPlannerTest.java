package com.healthycoderapp;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.RepeatedTest;

class DietPlannerTest {

	 private DietPlanner dietPlanner;
	 
	 @BeforeEach
	 void setup()
	 {
		this.dietPlanner = new  DietPlanner(20,30,50);
	 }
	 @AfterEach
	 void tearDown()
	 {
		 System.out.println("The test is completed!");
	 }
	@RepeatedTest(value= 10, name=RepeatedTest.LONG_DISPLAY_NAME)
	void Should_Return_CorrectDietPlan_When_CorrectCoder()
	{
		//given
		Coder coders = new Coder(1.82,75.0,26,Gender.MALE);
		DietPlan excpected  = new DietPlan(2202,110,73,275);
		
		//when
		DietPlan actual = dietPlanner.calculateDiet(coders);
		
		//then
		assertAll(
				() -> assertEquals(excpected.getCalories(),actual.getCalories()),
				() -> assertEquals(excpected.getProtein(),actual.getProtein()),
				() -> assertEquals(excpected.getFat(),actual.getFat()),
				() -> assertEquals(excpected.getCarbohydrate(),actual.getCarbohydrate())
				);
	}
	
	
}
