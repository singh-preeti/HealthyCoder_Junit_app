package com.healthycoderapp;

import static org.junit.jupiter.api.Assertions.*;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

class BMICalculatorTest {
	 private String enviroment = "prod";
	 
	 @Nested
	 class  IsDietRecommendedTest{
		 @ParameterizedTest(name= "weight={0}, height={1}")
			//@ValueSource(doubles = {89.0,95.0,60.0})
			//@CsvSource(value= {"89.0,1.72", "95.0,1.75"})
			@CsvFileSource(resources = "/diet-recommended-input-data.csv",numLinesToSkip =1)
			void should_ReturnFalse_When_DietRecommended(Double coderweight, Double coderheight) {
				//assertTrue(BMICalculator.isDietRecommended(89.0,1.72));
				
				//given
				 double weight = coderweight;
				 double height = coderheight;
				//when
				  boolean recommended = BMICalculator.isDietRecommended(weight,height);
				//then
				  assertTrue(recommended);
			}
		 @Test
			void should_ReturnThrowsArithmeticException_When_HeightZero() {
				//assertTrue(BMICalculator.isDietRecommended(89.0,1.72));
				
				//given
				 double weight = 50.0;
				 double height = 0.00;
				//when
				  Executable executable = () -> BMICalculator.isDietRecommended(weight,height);
				//then
				  assertThrows(ArithmeticException.class,executable);
			}	

	 }
	 @Nested
	class FindCodersWithWorstBmiTests{
		 @Test
			void should_ReturnCoderWithWorstBmiIn_When_CoderListHas10000Elements()
			{
				//given
			 assumeTrue(BMICalculatorTest.this.enviroment.equals("prod"));
				List<Coder> coders = new ArrayList<>();
				for(int i=0; i <10000; i++)
				{
					coders.add(new Coder(1.0+i,10.0+i));
				}
				//when
				Executable executable = () -> BMICalculator.findCoderWithWorstBMI(coders);
				//then
				assertTimeout(Duration.ofMillis(500), executable);
			} 
		 @Test
			void should_ReturnCoderWithWorstBMI_When_CoderListNotEmpty()
			{
				// given
				List<Coder> coders = new ArrayList<>();
				coders.add(new Coder(1.80,60.0));
				coders.add(new Coder(1.82,90.0));
				coders.add(new Coder(1.82,80.0));
				coders.add(new Coder(1.83,95.0));
				coders.add(new Coder(1.70,60.0));
				
				// when
				Coder coderObj = BMICalculator.findCoderWithWorstBMI(coders);
				
				//then
				assertAll(
						() -> assertEquals(1.83,coderObj.getHeight()),
						() -> assertEquals(98.0,coderObj.getWeight())
				);
			}
		 @Test
			void should_ReturnNullWorstBMI_When_CoderListEmpty()
			{
				//given
				List<Coder> coders = new ArrayList<>();
				
				// when
				Coder coderObj = BMICalculator.findCoderWithWorstBMI(coders);
				
				//then
				assertNull(coderObj);
			}
	 }

		// Repeated Tests
	
	//test performances
	
	@Nested
	class GetBmiScoresTests
	{
		@Test
		void should_ReturnCorrectBMIScoreArray_When_CoderListNotEmpty()
		{
			//given
			List<Coder> coders = new ArrayList<>();
			coders.add(new Coder(1.80,60.0));
			//coders.add(new Coder(1.82,95.0));
			coders.add(new Coder(1.82,64.7));
			//coders.add(new Coder(1.83,95.0));
			//coders.add(new Coder(1.70,60.0));
			
			double[] expected = {18.52,19.53};
			//when
			double[] bmiscores = BMICalculator.getBMIScores(coders);
			
			//then
			assertArrayEquals(expected,bmiscores);
		}
	}
	
	//Test Array equality
	
	
	}



















